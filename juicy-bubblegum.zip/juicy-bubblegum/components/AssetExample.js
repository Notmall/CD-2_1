import React from 'react';
import { Text, View, StyleSheet, Image, Button ,Separator, SafeAreaView, Alert, Linking} from 'react-native';

export default function AssetExample() {
  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>
       
      </Text>
      <Image style={styles.logo} source={require('../assets/sovremennye-problemy-trebuyut-sovremennyh-resheniy-4.jpg')} />
    </View>
  );
}

const App2 = () => (
  <SafeAreaView style={styles.container}>
    <View>
      <Button style={styles.butt}
        title="решить"
         color="black"
        onPress={ ()=>{ Linking.openURL('https://www.youtube.com/watch?v=dQw4w9WgXcQ')}}
      />
    </View>
    <Separator/>
    
  </SafeAreaView>
);

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 1,
  },
  paragraph: {
    margin: 0,
    marginTop: 0,
    fontSize: 14,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  logo: {
    height: 360,
    width: 360,
  }
});
